function tragetoria() {
    var velocidadeInicial = parseFloat(document.getElementById("velocidade").value);
    var angulo = parseFloat(document.getElementById("angulo").value);
    var gravidade = parseFloat(document.getElementById("gravidade").value);
    var alturaInicial = parseFloat(document.getElementById("alturaInicial").value);

    if (!verificacao1(velocidadeInicial, angulo, gravidade, alturaInicial)) {
        return;
    }

    ({ velocidadeInicial, angulo, gravidade, alturaInicial } = verificacao2(velocidadeInicial, angulo, gravidade, alturaInicial));

    var tempoSubida = calcularTempoSubida(velocidadeInicial, angulo, gravidade);
    var alturaMaxima = calcularAlturaMaxima(velocidadeInicial, angulo, gravidade, alturaInicial);
    var tempoDescida = calcularTempoDescida(alturaMaxima, gravidade);
    var alcanceFinal = calcularAlcanceFinal(velocidadeInicial, angulo, gravidade);
    var tragetoriaObliqua = calcularTragetoria(velocidadeInicial, angulo, gravidade, tempoSubida, alturaInicial);

    document.getElementById("spanSituacao").innerHTML =
        "O tempo de Subida é: " + tempoSubida.toFixed(2) + " segundos<br>" +
        "O tempo de Descida é: " + tempoDescida.toFixed(2) + " segundos<br>" +
        "A Altura Máxima é: " + alturaMaxima.toFixed(2) + " metros<br>" +
        "O Ponto Final é: " + alcanceFinal.toFixed(2) + " metros<br>" +
        "Trajetória (x, y): <br>" +
        tragetoriaObliqua.pontosTrajetoria.map(p => `(${p.x}, ${p.y})`).join(" | ");
}

// Verificação
function verificacao1(velocidadeInicial, angulo, gravidade, alturaInicial) {
    if (
        velocidadeInicial > 100 || velocidadeInicial < 0 ||
        angulo > 90 || angulo < 0 ||
        gravidade > 30 || gravidade < 0 ||
        (alturaInicial && (alturaInicial < 0 || alturaInicial > 100))
    ) {
        document.getElementById("spanSituacao").textContent =
            "Valor incorreto. Verifique os dados (0 ≤ velocidade ≤ 100, 0° < ângulo ≤ 90°, 0 ≤ gravidade ≤ 30, 0 ≤ altura ≤ 100).";
        return false;
    }
    return true;
}

function verificacao2(velocidadeInicial, angulo, gravidade, alturaInicial) {
    if (isNaN(velocidadeInicial)) velocidadeInicial = 50;
    if (isNaN(angulo)) angulo = 45;
    if (isNaN(gravidade)) gravidade = 9.8;
    if (isNaN(alturaInicial)) alturaInicial = 0;

    return { velocidadeInicial, angulo, gravidade, alturaInicial };
}

// Cálculos
function calcularTempoSubida(velocidadeInicial, angulo, gravidade) {
    return (velocidadeInicial * Math.sin(angulo * Math.PI / 180)) / gravidade;
}

function calcularAlturaMaxima(velocidadeInicial, angulo, gravidade, alturaInicial) {
    var altura = Math.pow(velocidadeInicial * Math.sin(angulo * Math.PI / 180), 2) / (2 * gravidade);
    return altura + alturaInicial;
}

function calcularTempoDescida(alturaMaxima, gravidade) {
    return Math.sqrt((2 * alturaMaxima) / gravidade);
}

function calcularAlcanceFinal(velocidadeInicial, angulo, gravidade) {
    return (Math.pow(velocidadeInicial, 2) * Math.sin(2 * angulo * Math.PI / 180)) / gravidade;
}

function calcularTragetoria(velocidadeInicial, angulo, gravidade, tempoSubida, alturaInicial) {
    var anguloEmRad = angulo * Math.PI / 180;
    var velocidadeX = velocidadeInicial * Math.cos(anguloEmRad);
    var velocidadeY = velocidadeInicial * Math.sin(anguloEmRad);

    var pontos = [];
    var deltaTempo = 0.1;
    var tempoTotal = (velocidadeY + Math.sqrt(Math.pow(velocidadeY, 2) + 2 * gravidade * alturaInicial)) / gravidade;

    for (var i = 0; i <= tempoTotal; i += deltaTempo) {
        var x = velocidadeX * i;
        var y = alturaInicial + velocidadeY * i - (0.5 * gravidade * Math.pow(i, 2));
        if (y < 0) break;
        pontos.push({ x: x.toFixed(2), y: y.toFixed(2) });
    }

    return { pontosTrajetoria: pontos };
}
