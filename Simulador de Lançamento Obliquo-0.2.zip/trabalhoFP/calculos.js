
function trajetoria() {
    var velocidadeInicial = parseFloat(document.getElementById("velocidade").value);
    var angulo = parseFloat(document.getElementById("angulo").value);
    var gravidade = parseFloat(document.getElementById("gravidade").value);
    var alturaInicial = parseFloat(document.getElementById("alturaInicial").value);

    if (!verificacao1(velocidadeInicial, angulo, gravidade, alturaInicial)) return;

    ({ velocidadeInicial, angulo, gravidade, alturaInicial } = verificacao2(velocidadeInicial, angulo, gravidade, alturaInicial));

    var tempoSubida = calcularTempoSubida(velocidadeInicial, angulo, gravidade);
    var alturaMaxima = calcularAlturaMaxima(velocidadeInicial, angulo, gravidade, alturaInicial);
    var tempoDescida = calcularTempoDescida(alturaMaxima, gravidade);
    var alcanceFinal = calcularAlcanceFinal(velocidadeInicial, angulo, gravidade);
    var trajetoriaObliqua = calcularTrajetoria(velocidadeInicial, angulo, gravidade, alturaInicial);

    document.getElementById("spanSituacao").innerHTML =
        "Tempo de Subida: " + tempoSubida.toFixed(2) + " s<br>" +
        "Tempo de Descida: " + tempoDescida.toFixed(2) + " s<br>" +
        "Altura Máxima: " + alturaMaxima.toFixed(2) + " m<br>" +
        "Alcance Final: " + alcanceFinal.toFixed(2) + " m";

    desenharTrajetoriaAnimada(trajetoriaObliqua.pontosTrajetoria);
}

function verificacao1(v, a, g, h) {
    if (v > 100 || v < 0 || a > 90 || a <= 0 || g > 30 || g < 0 || (h && (h < 0 || h > 100))) {
        document.getElementById("spanSituacao").textContent =
            "Valor incorreto. Verifique os dados: 0 ≤ velocidade ≤ 100, 0° < ângulo ≤ 90°, 0 ≤ gravidade ≤ 30, 0 ≤ altura ≤ 100.";
        return false;
    }
    return true;
}

function verificacao2(v, a, g, h) {
    if (isNaN(v)) v = 50;
    if (isNaN(a)) a = 45;
    if (isNaN(g)) g = 9.8;
    if (isNaN(h)) h = 0;
    return { velocidadeInicial: v, angulo: a, gravidade: g, alturaInicial: h };
}

function calcularTempoSubida(v, a, g) {
    return (v * Math.sin(a * Math.PI / 180)) / g;
}

function calcularAlturaMaxima(v, a, g, h) {
    var altura = Math.pow(v * Math.sin(a * Math.PI / 180), 2) / (2 * g);
    return altura + h;
}

function calcularTempoDescida(altura, g) {
    return Math.sqrt((2 * altura) / g);
}

function calcularAlcanceFinal(v, a, g) {
    return (Math.pow(v, 2) * Math.sin(2 * a * Math.PI / 180)) / g;
}

function calcularTrajetoria(v, a, g, h) {
    var rad = a * Math.PI / 180;
    var vX = v * Math.cos(rad);
    var vY = v * Math.sin(rad);
    var pontos = [];
    var deltaT = 0.1;
    var tTotal = (vY + Math.sqrt(Math.pow(vY, 2) + 2 * g * h)) / g;

    for (var t = 0; t <= tTotal; t += deltaT) {
        var x = vX * t;
        var y = h + vY * t - 0.5 * g * t * t;
        if (y < 0) break;
        pontos.push({ x: x.toFixed(2), y: y.toFixed(2) });
    }
    return { pontosTrajetoria: pontos };
}

function desenharTrajetoriaAnimada(pontos) {
    const canvas = document.getElementById("canvasFoguete");
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const escalaX = canvas.width / (pontos[pontos.length - 1].x || 1);
    const escalaY = canvas.height / Math.max(...pontos.map(p => parseFloat(p.y) || 1));

    let i = 0;
    ctx.beginPath();

    const intervalo = setInterval(() => {
        if (i >= pontos.length) {
            clearInterval(intervalo);
            return;
        }

        const x = pontos[i].x * escalaX;
        const y = canvas.height - pontos[i].y * escalaY;

        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
            ctx.strokeStyle = "lime";
            ctx.lineWidth = 2;
            ctx.stroke();
        }
        i++;
    }, 20);
}
